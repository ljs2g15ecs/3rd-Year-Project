#include "SIMON_test.h"

#include <stdio.h>

int		main()
{
	test();
}