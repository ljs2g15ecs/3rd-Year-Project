#include "SIMON_host.h"
#include "SIMON_file.h"

BLOCK	readBLOCK(char* fileNAME, int* pos)
{
	
}