#ifndef	SIMON_FILE_H
#define SIMON_FILE_H

#include <stdio.h>

#include "SIMON_host.h"

BLOCK	readBLOCK(char* fileNAME, int* pos);

#endif

